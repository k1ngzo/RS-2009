/**
 * @author 'Vexia
 *
 */
package org.keldagrim.game.content.skill.free;