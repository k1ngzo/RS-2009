package org.keldagrim.game.node.entity.player.link.skillertasks;

public enum Difficulty {
	NOVICE, INTERMEDIATE, ADVANCED, ELITE
}