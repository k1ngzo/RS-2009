package org.keldagrim.game.content.skill.member.construction;

/**
 * Family crest types.
 * @author Emperor
 * >ORDINAL BOUND<
 */
public enum CrestType {

	ARRAV,
	ASGARNIA,
	DORGESHUUN,
	DRAGON,
	FAIRY,
	GUTHIX,
	HAM,
	HORSE,
	JOGRE,
	KANDARIN,
	MISTHALIN,
	MONEY,
	SARADOMIN,
	SKULL,
	VARROCK,
	ZAMORAK;
}