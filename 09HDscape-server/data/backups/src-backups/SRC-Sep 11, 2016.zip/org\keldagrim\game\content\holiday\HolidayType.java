package org.keldagrim.game.content.holiday;

/**
 * The holiday type.
 * @author Vexia
 */
public enum HolidayType {
	HALLOWEEN(), CHRISTMAS(), EASTER(), THANKSGIVING;
}
