/**
 * Holds more important content classes.
 * 
 * @author Emperor
 *
 */
package org.keldagrim.game.content;